#if ! defined(_PMGT_TEST_H)
#define _PMGT_TEST_H 1

status_t
PT_test(
  Option_t *option,  /* I */
  Config_t *config,  /* I */
  Base_t *base  /* I */
);

#endif  /* _PMGT_TEST_H */
