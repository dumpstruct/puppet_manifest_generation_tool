#if ! defined(_PMGT_OPTION_H)
#define _PMGT_OPTION_H 1

status_t
PO_get(
  Option_t *option,  /* o */
  int *max,  /* io */
  char **params  /* io */
);

#endif  /* _PMGT_OPTION_H */
