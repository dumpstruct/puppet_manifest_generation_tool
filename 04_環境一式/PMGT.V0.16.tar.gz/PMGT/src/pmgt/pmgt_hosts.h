#if ! defined(_PMGT_HOSTS_H)
#define _PMGT_HOSTS_H 1

status_t
PH_hosts(
  Option_t *option,  /* I */
  Config_t *config,  /* I */
  Base_t *base  /* I */
);

#endif  /* _PMGT_HOSTS_H */
