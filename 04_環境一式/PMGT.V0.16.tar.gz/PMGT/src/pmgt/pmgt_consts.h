#if ! defined(_PMGT_CONSTS_H)
#define _PMGT_CONSTS_H 1

status_t
PN_consts(
  Option_t *option,  /* I */
  Config_t *config,  /* I */
  Base_t *base  /* I */
);

#endif  /* _PMGT_CONSTS_H */
