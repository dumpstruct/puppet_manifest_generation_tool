
# *,*,c_ea_ha,'v1'
#FACTER_C_EA_HA='@'; export FACTER_C_EA_HA

# *,HMPM01,c_ea_h1,'v2'
#FACTER_C_EA_H1='@'; export FACTER_C_EA_H1

# s1,*,c_e1_ha,'v4'
#FACTER_C_E1_HA='@'; export FACTER_C_E1_HA

# s1,HMPM01,c_e1_h1,'v5'
#FACTER_C_E1_H1='@'; export FACTER_C_E1_H1

# *,*,c_hn6,sprintf("%.6s",$pmgt_hostname)
#FACTER_C_HN6='@'; export FACTER_C_HN6

# *,*,c_hn1,sprintf("%.1s",$pmgt_hostname)
#FACTER_C_HN1='@'; export FACTER_C_HN1

# *,*,c_hn2to6,regsubst($c_hn6,'.','')
#FACTER_C_HN2TO6='@'; export FACTER_C_HN2TO6

# *,*,c_hn2,regsubst($c_hn2to6,'....$','')
#FACTER_C_HN2='@'; export FACTER_C_HN2

# *,*,c_hn3to6,regsubst($c_hn6,'..','')
#FACTER_C_HN3TO6='@'; export FACTER_C_HN3TO6

# *,*,c_hn3to4,regsubst($c_hn3to6,'..$','')
#FACTER_C_HN3TO4='@'; export FACTER_C_HN3TO4
